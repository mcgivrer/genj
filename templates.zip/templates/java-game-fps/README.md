# README

This basic java project ${PROJECT_NAME} version ${PROJECT_VERSION} 
contains the ${MAINCLASS} class into the ${PACKAGE}.

## Project structure

![Structure de du projet ${PROJECT_NAME}](src/docs/illustrations/demo-structure.svg  "${PROJECT_NAME} project file structure")

## Screenshot

![Screenshot of the ${PROJECT_NAME}](src/docs/illustrations/demo101.png "Screenshot of the ${PROJECT_NAME}")

by ${AUTHOR_NAME} <${AUTHOR_EMAIL}>