# Project demo101

## Preface

This is the preface for the documentation of the project demo101.
You must rewrite this document according to your specifications.

>[!NOTE]
>Please use the Markdown text format to easily create 
>docs in multiple formats with the 'pandoc' tool. 

Frederic Delorme frederic.delorme@gmail.com
