# Project demo101

## Preface

This is the preface for the documentation of the project ${PROJECT_NAME}.
You must rewrite this document according to your specifications.

>[!NOTE]
>Please use the Markdown text format to easily create 
>docs in multiple formats with the 'pandoc' tool. 

${AUTHOR_NAME} ${AUTHOR_EMAIL}
